package domain;

public class Control_Authenticator {
	
	public static void authenticate() {
		
	}
}
