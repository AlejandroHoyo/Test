
package domain; 

public class Control_User {

	public static void register() {
		
	}

}
